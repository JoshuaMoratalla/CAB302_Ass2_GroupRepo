package Shapes;


import GUI.DrawPanel;

import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 *
 *
 *
 * This class is to create a simple rectangles.
 *
 * @author Abdulrahman Albaqami n10382241
 */

public class CustomRectangle extends ShapeInterface  {


    @Override
    public void draw(Graphics2D g)
    {
        if(points.size() < 2) return;

        Point startPoint = points.get(0);
         Point endPoint = points.get(1);

        g.setColor(lineColor);
        g.drawRect(Math.min(startPoint.x, endPoint.x), Math.min(startPoint.y, endPoint.y), Math.abs(startPoint.x - endPoint.x), Math.abs(startPoint.y - endPoint.y));
        g.setColor(fillColor);
        g.fillRect(Math.min(startPoint.x, endPoint.x), Math.min(startPoint.y, endPoint.y), Math.abs(startPoint.x - endPoint.x), Math.abs(startPoint.y - endPoint.y));


    }
    @Override
    public boolean maxPointsReached(){
        return  points.size() == 2;
    }



}
