package Shapes;

import java.awt.*;
import java.util.List;
import java.util.ArrayList;

/***
 *
 *
 *
 *
 * This class is to draw simple Polygon. The way it works that everytime the left mouse clicked it will generate a point and connect it with the first point all the time.
 * To complete the polygon user must right click the mouse to end it .
 *
 * @author Abdulrahman Albaqami n10382241
 * */

public class CustomPolygon extends ShapeInterface {


    @Override
    public void draw(Graphics2D g)
    {
        int numPoints = points.size();

        int[] xPoints = new int[numPoints];
        int[] yPoints = new int[numPoints];

        for(int i = 0; i < numPoints; i++)
        {
            Point point = points.get(i);
            xPoints[i] = point.x;
            yPoints[i] = point.y;
        }

        // Line
        g.setColor(lineColor);
        g.drawPolygon(xPoints, yPoints, numPoints);

        // Fill
        g.setColor(fillColor);
        g.fillPolygon(xPoints, yPoints, numPoints);
    }

    @Override
    public boolean maxPointsReached(){
        return false;
    }
}
