package Shapes;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 *
 *
 *
 *
 * This is an interface class is made to make the program more abstract. It countains all the motheds that each shape needs.
 *
 *
 * @author Abdulrahman Albaqami n10382241
 * */

public abstract class ShapeInterface {

    public List<Point> points = new ArrayList<Point>();
    Color lineColor = Color.black;
    Color fillColor = new Color(0, 0, 0, 0);
    
    /*
    *
    *
    *
    * */
    public abstract void draw(Graphics2D g);

    /*
     *
     *
     *
     * */
    public void addPoint(Point point)
    {
        points.add(point);
    }

    /*
     *
     *
     *
     * */
    public abstract boolean maxPointsReached();

    /*
     *
     *
     *
     * */
    public void setLineColor(Color color)
    {
        lineColor = color;
    }

    /*
     *
     *
     *
     * */
    public void setFillColor(Color color)
    {
        fillColor = color;
    }
}
