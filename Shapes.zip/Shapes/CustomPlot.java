package Shapes;

import java.awt.*;

/***
 *
 *
 *
 *
 * @author abdul Albaqami n10382241
 *
 * */

public class CustomPlot extends ShapeInterface {
    @Override
    public void draw(Graphics2D g) {

        // If we do not have a start AND an end point, do NOT draw.
        if(points.size() < 1) return;

        Point startPoint = points.get(0);

        g.setColor(lineColor);
        /*Here I have cheated I did not really know how to draw a simple plot so I used drawline with stupid parameters LOL, also changed the maxpoints */
        g.drawLine(startPoint.x,startPoint.y,startPoint.x,startPoint.y);
    }

    @Override
    public boolean maxPointsReached(){
        return points.size() == 1;
    }
}
