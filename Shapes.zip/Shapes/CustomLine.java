package Shapes;

import java.awt.*;

/***
 *
 *
 *
 *
 * This class is to draw simple line
 *
 * @author Abdulrahman Albaqami n10382241
 * */

public class CustomLine extends ShapeInterface {

    @Override
    public void draw(Graphics2D g) {

        // If we do not have a start AND an end point, do NOT draw.
        if(points.size() < 2) return;

        Point startPoint = points.get(0);
        Point endPoint = points.get(1);

        g.setColor(lineColor);
        g.drawLine(startPoint.x, startPoint.y, endPoint.x,endPoint.y);
    }


    @Override
    public boolean maxPointsReached(){
        return points.size() == 2;
    }
}
