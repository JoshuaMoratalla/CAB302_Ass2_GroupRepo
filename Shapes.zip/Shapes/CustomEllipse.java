package Shapes;


import java.awt.*;

/**
 *
 *
 *
 * This class is to draw simple ellipse.
 *
 * @author Abdulrahman Albaqami n10382241
 */
public class CustomEllipse extends ShapeInterface{

    @Override
    public void draw(Graphics2D g)
    {
        if(points.size() < 2) return;

        Point startPoint = points.get(0);
        Point endPoint = points.get(1);

        g.setColor(lineColor);
        g.drawOval(Math.min(startPoint.x, endPoint.x), Math.min(startPoint.y, endPoint.y), Math.abs(startPoint.x - endPoint.x), Math.abs(startPoint.y - endPoint.y));
        g.setColor(fillColor);
        g.fillOval(Math.min(startPoint.x, endPoint.x), Math.min(startPoint.y, endPoint.y), Math.abs(startPoint.x - endPoint.x), Math.abs(startPoint.y - endPoint.y));
    }
    @Override
    public boolean maxPointsReached(){
        return  points.size() == 2;
    }
}
